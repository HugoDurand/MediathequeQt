#ifndef DBCONNECT_H
#define DBCONNECT_H

#include<iostream>


class DBConnect
{
public:
    DBConnect();

    bool ok;
};

#endif // DBCONNECT_H
